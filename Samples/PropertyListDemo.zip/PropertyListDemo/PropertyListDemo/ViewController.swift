//
//  ViewController.swift
//  PropertyListDemo
//
//  Created by Arvin on 11/20/16.
//  Copyright © 2016 Arvin. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var inputTextField: UITextField!
    @IBOutlet weak var outputTextField: UITextField!
    @IBOutlet weak var saveButton: UIButton!
    @IBOutlet weak var loadButton: UIButton!
    
    let BedroomFloorKey = "BedroomFloor"
    let BedroomWallKey = "BedroomWall"
    var bedroomFloorID: AnyObject = 101 as AnyObject
    var bedroomWallID: AnyObject = 101 as AnyObject
    
    
    @IBAction func saveAction(_ sender: Any) {
        let paths = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true) as NSArray
        let documentsDirectory = paths.object(at: 0) as! NSString
        let path = documentsDirectory.appendingPathComponent("GameData.plist")
        
        let dict: NSMutableDictionary = ["XInitializerItem": "DoNotEverChangeMe"]
        //saving values
        dict.setObject(bedroomFloorID, forKey: BedroomFloorKey as NSCopying)
        dict.setObject(bedroomWallID, forKey: BedroomWallKey as NSCopying)
        dict.setObject(inputTextField.text!, forKey: "inputTextField" as NSCopying)
        //...
        
        //writing to GameData.plist
        dict.write(toFile: path, atomically: false)
        
        let resultDictionary = NSMutableDictionary(contentsOfFile: path)
        print("Saved GameData.plist file is --> \(resultDictionary?.description)")
    }

    @IBAction func loadAction(_ sender: Any) {
        // getting path to GameData.plist
        let paths = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true) as NSArray
        let documentsDirectory = paths.object(at:0) as! NSString
        let path = documentsDirectory.appendingPathComponent("GameData.plist")
        
        let fileManager = FileManager.default
        
        //check if file exists
        if(!fileManager.fileExists(atPath: path)) {
            // If it doesn't, copy it from the default file in the Bundle
            if let bundlePath = Bundle.main.path(forResource: "GameData", ofType: "plist") {
                
                let resultDictionary = NSMutableDictionary(contentsOfFile: bundlePath)
                print("Bundle GameData.plist file is --> \(resultDictionary?.description)")
              
                //fileManager.copyItem(atPath: bundlePath, toPath: path)
             
                
                print("copy")
            } else {
                print("GameData.plist not found. Please, make sure it is part of the bundle.")
            }
        } else {
            print("GameData.plist already exits at path.")
            // use this to delete file from documents directory
            //fileManager.removeItemAtPath(path, error: nil)
        }
        
        let resultDictionary = NSMutableDictionary(contentsOfFile: path)
        print("Loaded GameData.plist file is --> \(resultDictionary?.description)")
        
        let myDict = NSDictionary(contentsOfFile: path)
        
        if let dict = myDict {
            //loading values
            bedroomFloorID = dict.object(forKey: BedroomFloorKey)! as AnyObject
            bedroomWallID = dict.object(forKey: BedroomWallKey)! as AnyObject
            outputTextField.text = (dict.object(forKey: "inputTextField")! as AnyObject) as? String
            //...
        } else {
            print("WARNING: Couldn't create dictionary from GameData.plist! Default values will be used!")
        }
        
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

